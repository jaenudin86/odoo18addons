## Module <pos_product_stock>

#### 03.12.2024
#### Version 18.0.1.0.0
#### ADD
- Initial Commit for POS Product Stock

#### 10.03.2025
#### Version 18.0.1.0.1
#### UPDT
- Commit for bug fix

