## Module <pos_zero_quantity_restrict>

#### 01.10.2024
#### Version 18.0.1.0.0
#### ADD
 - Initial Commit for POS Restriction For Zero Quantity.
