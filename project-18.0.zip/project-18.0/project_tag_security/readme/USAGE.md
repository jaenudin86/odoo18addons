1.  Go to Project > Configuration > Tags.
2.  Create or edit a project tag and set any allowed project.
3.  Go to the allowed project(s) and set the previous tag.
4.  Go to another project (not allowed) and you will not be able to set
    the previous tag.

If a tag has no allowed project(s) it will be visible in any
project/task.
