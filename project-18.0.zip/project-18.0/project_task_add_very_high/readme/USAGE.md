To use this module, you need to:

1.  Open a task or create a new one
2.  On the priority widget, three stars are displayed (instead of one)
3.  Click on the second star: the priority of this task is now set to
    High
4.  Click on the third star: the priority of this task is now set to
    Very High
