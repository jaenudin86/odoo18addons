Allows us to define groups directly on projects.
