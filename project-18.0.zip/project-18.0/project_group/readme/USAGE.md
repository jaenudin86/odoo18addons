Now, when we use Invited internal users options on visibility, a groups field will appear. Then, all users with access to the project will be able to see project and related tasks.
