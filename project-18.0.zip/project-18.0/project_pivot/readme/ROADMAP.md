This module is not compatible with 'project_list' and 'project_timeline'
because both modules replace the same actions.
