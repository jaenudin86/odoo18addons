This module introduces a pivot view for the projects, so that you can
analyze easily some data such as project planning dates, project status
and other information.
