To change the project display name pattern, follow these steps:

1.  Go to *Project \> Configuration \> Settings*.

2.  Edit the *Project display name pattern* field.

    The default format is `%(sequence_code)s - %(name)s`. You can use
    those same placeholders to customize the pattern.
