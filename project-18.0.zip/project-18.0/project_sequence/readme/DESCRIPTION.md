Add a sequence field to projects, filled automatically and add a code
sequence filter in tree view project.
