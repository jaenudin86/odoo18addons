To use this module, you need to:

1.  Go to the project icon.
2.  Click the button "create" to create a new project
3.  Fill in the field Project name and click the "create" button
4.  Now in the Kanban view see the project name when you are created
5.  Repeat this operation creating another project without the name.
