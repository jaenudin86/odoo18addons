In Kanban View:

1.  Go to Project \> Dashboard
2.  Group by "Parent Project"

In Tree View:

1.  Go to Project \>Configuration \> Projects
2.  Group by "Parent Project"

In form View:

1.  Go to Project \> Dashboard
2.  Open the projects settings
3.  Modify the "Parent Project" in settings tab
