This module introduces project parent and childs fields.
