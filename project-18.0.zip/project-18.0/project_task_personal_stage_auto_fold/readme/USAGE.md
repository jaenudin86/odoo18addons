1.  Go to Projects \> Select one \> Select a task assigned to you
2.  Change the stage to Done or to Cancelled
3.  Go to Tasks \> My Tasks \> Select the same task
4.  As you can see, the personal stage has also changed
