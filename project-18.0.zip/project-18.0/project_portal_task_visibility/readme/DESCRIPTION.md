This module changes behavior of task visibility. With this module,
portal users will only see task where they are explicitly set as
follower. So visibility on project only is no longer enough. However,
when creating a new task, all users following the project will
automatically follow the new task too.
