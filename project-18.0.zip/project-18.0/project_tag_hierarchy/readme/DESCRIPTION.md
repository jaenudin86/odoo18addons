Hierarchy is added to the project labels.
