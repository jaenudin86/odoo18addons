To configure the list of roles avalable:

1.  Go to *Project \> Configuration \> Project Roles*
2.  Add/remove roles according to your business processes

To manage assignments on particular project:

1.  Go to *Project \> Projects*
2.  Open project of interest
3.  Click on *Assignments* smart-button
4.  Add/remove assignments as needed

To manage assignments:

1.  Go to *Project \> Assignments*
2.  Add/remove assignments as needed

Also, it's recommended to consider using `web_m2x_options` module in
order to avoid unneeded creation of roles and projects using Quick
Create action by setting the `web_m2x_options.create` system parameter
to `False`.
