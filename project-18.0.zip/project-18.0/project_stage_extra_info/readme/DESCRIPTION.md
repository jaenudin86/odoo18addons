This module adds a Description and Is closed stage field on Project
stages. Also adds its filters on Project.
