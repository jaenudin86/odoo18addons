To use this module, you need to:

1.  Have Manager rights for Project group to create project stages.
2.  To enable Project Stages goto Settings \> Project \> enable Project
    Stages.
3.  Go to *Project \> Configuration \> Project Statuses*.
4.  When creating a project or editing it, select the status
