TODO

Would be nice to have this feature working for projects shared in "Edit mode". 