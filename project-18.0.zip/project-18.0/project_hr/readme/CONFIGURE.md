For setting employee categories at project level:

1.  Go to *Project \> Projects*.
2.  Click on the 3 vertical dots of one of the project kanban cards for
    unfolding options and select "Settings".
3.  Put the wanted employee categories on the field "Employee
    Categories".

For setting employee categories:

1.  Go to *Project \> All Tasks*.
2.  Select or create a new task.
3.  Put the wanted employee categories on the field "Employee
    categories".
4.  If there's already some employee categories selected at project
    level, those will be the only selectable ones in the task.
