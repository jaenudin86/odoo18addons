1.  Go to *Project \> Search \> Tasks*.
2.  If there's an employee category selected in the task, you will only
    be able to select those users whose employee belongs to that
    category.
