This module implements task codes in the portal. It allows users to:

- Use task codes instead of IDs in portal URLs.
- Search for tasks by their unique code.
- Display task codes in portal task views.
- Display in the task the URL to access to the task from the portal for easy sharing.
