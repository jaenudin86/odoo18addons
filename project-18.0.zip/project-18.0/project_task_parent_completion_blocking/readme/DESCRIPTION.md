Prevents a task from being completed if a child task isn't completed.
