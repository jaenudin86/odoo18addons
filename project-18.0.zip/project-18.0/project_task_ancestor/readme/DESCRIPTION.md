For some companies, having ancestor tasks is essential for structuring 
and organizing their work.
However, in version 18, Odoo removed this feature, considering it unnecessary.

This module restores the ancestor task field with its associated logic, 
making it available again in Timesheets and Project reports.