This module extends the name_search() and name_get() methods of the
project.task model to search for, and display the ID of the task in the
name field.

This module will simplify your operations if they heavily rely on the
task ID. For instance, you can select a task by its ID when creating a
timesheet record.
