The task's display name will change to a concatenation of its ID and
task name (e.g., \[ID\] task_name). You can search for the task using
its ID in the Many2one field or in the search view.
