To use this module, you need to:

1.  Belong to the "Show Full Accounting Features" and "Analytic
    Accounting" groups.
2.  On the lines of purchase orders or invoices, indicate the analytical
    account associated with the project.
