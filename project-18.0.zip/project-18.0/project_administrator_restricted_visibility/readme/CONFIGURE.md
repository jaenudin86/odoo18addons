To configure this module, you need to:

1.  Go to *Settings \> Users & Companies \> Users*
2.  Create a user or edit an existing one.
3.  A new access group called 'Restricted Project Administrator' under
    the 'Projects' category can be selected.
