The new group has the same access rights as the administrator (and see
the same menus), but the project visibility is restricted as a project
user.
