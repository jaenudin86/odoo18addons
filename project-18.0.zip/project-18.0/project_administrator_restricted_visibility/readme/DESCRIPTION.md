This module extends the functionality of 'Project' module to add a new
'Project Administrator' access group with restricted visibility to the
projects.
