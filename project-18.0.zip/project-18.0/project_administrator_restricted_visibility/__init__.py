from .hooks import uninstall_hook
