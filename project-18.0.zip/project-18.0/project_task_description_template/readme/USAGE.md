To use this module:

Select the description template you want to use in a task.
