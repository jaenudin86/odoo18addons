This module allow to define description templates for a task and use
them to generate the description of the task.
