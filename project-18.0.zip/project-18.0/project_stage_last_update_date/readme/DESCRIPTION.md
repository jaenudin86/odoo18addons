This module adds a new field to record the last date when the project
stage was updated.
