To use this module, you need to:

1.  Go to Project -\> Configuration -\> Projects
2.  Select a project and, under "Pull Request URIs", select the stages
    where you would like a PR URI to be required
3.  Go to Dashboard and select a project
4.  Attempt to move one of the project's task without a PR URI into one
    of the stages you selected to require a PR; you will receive a
    Validation Error
5.  To add a PR URI to a task, click on the task and go to the "Extra
    Info" tag
