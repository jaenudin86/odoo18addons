This module extends the functionality of project to allow you to add PR
URIs to tasks and require PR URIs before tasks can be moved to certain
stages.
