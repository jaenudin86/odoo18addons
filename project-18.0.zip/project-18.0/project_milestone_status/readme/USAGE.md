- Execution: the percentage between hours of tasks completed and pending tasks
- Dedication: the percentage between planned hours and effective hours

These percentages are shown in Milestones and Project Updates of projects.
