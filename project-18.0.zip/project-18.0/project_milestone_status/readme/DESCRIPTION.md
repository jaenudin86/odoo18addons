This module allows you to have the percentage of the execution of a project.
