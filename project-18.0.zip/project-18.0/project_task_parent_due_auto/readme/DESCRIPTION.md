Updates the parent task's due date when a child's due date is changed.
