This module adds a sequential code for tasks.
