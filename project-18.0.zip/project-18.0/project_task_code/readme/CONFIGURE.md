To change the task code sequence, you must:

1.  Activate the developer mode.
2.  Go to Settings \> Technical \> Sequences & Identifiers \> Sequences.
3.  Click on "Task code" sequence to edit.
