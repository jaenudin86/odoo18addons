## Module <pos_product_limit_odoo>

#### 19.11.2024
#### Version 18.0.1.0.0
#### ADD
- Initial commit for Pos Product Limit Odoo
