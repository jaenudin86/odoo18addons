## Module <pos_discount_manager>

#### 29.05.2025
#### Version 18.0.1.0.0
#### ADD
- Initial Commit POS Discount Manager Approval
