from . import test_base_model_restrict_update
