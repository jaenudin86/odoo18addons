- Laurent Mignon \<<laurent.mignon@acsone.eu>\>
- Akim Juillerat \<<akim.juillerat@camptocamp.com>\>
- SodexisTeam \<<dev@sodexis.com>\>

Trobz

- Dung Tran \<<dungtd@trobz.com>\>
- Khoi (Kien Kim) \<<khoikk@trobz.com>\>
