To use this module, you need to open the models' form view and check
field "Force No-Update"
