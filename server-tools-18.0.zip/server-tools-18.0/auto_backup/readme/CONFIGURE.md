Go to *Settings -\> Database Structure -\> Automated Backup* to create
your configurations for each database that you needed to backups.
