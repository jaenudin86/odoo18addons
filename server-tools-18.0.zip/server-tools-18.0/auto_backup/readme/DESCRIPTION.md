A tool for all your back-ups, internal and external!
