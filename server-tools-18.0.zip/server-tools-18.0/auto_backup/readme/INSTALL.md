Before installing this module, you need to execute:

    pip3 install pysftp==0.2.9
