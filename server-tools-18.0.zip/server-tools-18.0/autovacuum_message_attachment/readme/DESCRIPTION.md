Odoo create a lot of message and/or mails. With time it can slow the
system or take a lot of disk space. The goal of this module is to clean
these message once they are obsolete. The same may happen with
attachment that we store. You can choose various criterias manage which
messages you want to delete automatically.
