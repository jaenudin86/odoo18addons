This module is set to auto-install. Simply install and enable:

1. `web_editor` (Odoo core module)
2. `base_fontawesome` (from this repository)

The module will be automatically installed and FontAwesome icons will become visible in the web editor.
