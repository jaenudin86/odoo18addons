The development of this module has been financially supported by:

- Odoo Community Association
