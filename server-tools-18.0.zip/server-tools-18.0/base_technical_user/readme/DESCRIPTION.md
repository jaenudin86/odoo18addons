This module extends the functionality of company management. It allows
you to bind a technical user on the company in order to use it in batch
processes.

The technical user must - be inactive to avoid login - be in the
required groups depending of what you need to do
