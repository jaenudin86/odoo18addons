To use this module, you need to:

1.  Go to *Settings \> Technical \> Automation \> Scheduled Actions*.
2.  In the form view go to the tab *Mutually Exclusive Scheduled
    Actions*.
3.  Fill it with the actions that should be blocked while running the
    action you are editing. Note that this is mutual and the selected
    actions will block the initial action when running.
