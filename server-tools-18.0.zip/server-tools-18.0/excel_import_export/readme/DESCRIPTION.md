The module provide pre-built functions and wizards for developer to
build excel import / export / report with ease.

Without having to code to create excel file, developer do,

- Create menu, action, wizard, model, view a normal Odoo development.
- Design excel template using standard Excel application, e.g., colors,
  fonts, formulas, etc.
- Instruct how the data will be located in Excel with simple dictionary
  instruction or from Odoo UI.
- Odoo will combine instruction with excel template, and result in final
  excel file.
