To install this module, you need to install following python library,
**xlrd, xlwt, openpyxl**.

Then, simply install **excel_import_export**.

For demo, install **excel_import_export_demo**
