If you have existing templates from the version 16.0.1.2.0 or earlier,
you need to click 'REMOVE EXPORT ACTION' and then click 'ADD EXPORT
ACTION' in these templates for export actions to work as expected.
