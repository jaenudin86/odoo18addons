Provide up to date [Fontawesome](http://fontawesome.io/) resources.

Current version: 6.5.1 (the version of this module matches it).
