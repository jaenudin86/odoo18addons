- Modify the general search parts (e.g. in tree view or many2one fields)
- Add better order by handling
- This module will not be necessary from version 16 ([\[IMP\] Better
  handling of indexes \#83015](https://github.com/odoo/odoo/pull/83015))
