## Module <barcode_scanning_sale_purchase>

#### 01.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial Commit for Barcode Scanning Support For Sale and Purchase
