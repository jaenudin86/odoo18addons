1.  Go to an analytical plan/account and define your employee's
    department.
2.  Go to an analytical plan/account and define a different department
    than your employee's department.
3.  Go to an analytical plan/account and leave the department empty.
4.  Users without the "Invoicing / Invoicing" permission will be able to
    see only the plans/analytical accounts of the user's employee's
    department.
5.  Users with the "Analytic Accounting (without department)" will be
    able to view the plans/analytical accounts without a department, as
    will users with the permission "Invoicing / Invoicing".
