The module restores the possibility of defining analytical tags in
expenses so that the analytical items generated have those tags.
