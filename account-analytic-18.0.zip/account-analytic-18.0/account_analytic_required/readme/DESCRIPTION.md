This module adds an option *analytic policy* on accounts. You have the
choice between 4 policies : *always*, *never*, *posted moves* and empty
(*optional*).
