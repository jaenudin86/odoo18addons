The goal of this module is to ease analytic distribution management on
purchase order. This module add analytic distribution on purchase order.

If all lines of the purchase order have the same analytic distribution,
the analytic distribution on the purchase order is automatically set
with this value. If a analytic distribution is set on the purchase
order, all lines of the purchase will take this value.
