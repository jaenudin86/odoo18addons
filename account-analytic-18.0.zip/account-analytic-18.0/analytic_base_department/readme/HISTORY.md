## 13.0.1.0.0 (2020-01-07)

Migrated to odoo 13.

## 12.0.1.0.0 (2018-12-04)

Migrated to odoo 12.

## 11.0.1.0.0 (2017-12-27)

Migrated to odoo 11.

## 10.0.1.0.0 (2017-04-18)

Migrated to odoo 10.

## 9.0.1.0.0 (2016-01-28)

Migrated to odoo 9.

## 8.0.1.0.0 (2014-07-22)

First version.
