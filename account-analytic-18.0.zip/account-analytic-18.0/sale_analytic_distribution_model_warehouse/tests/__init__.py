from . import test_so_analytic_by_warehouse
