To configure the analytic distributions:

1. Go to **Accounting > Configuration > Analytic Distribution Models**
2. Create a new distribution model or edit an existing one
3. Set the **Warehouse** field to specify which warehouse this model applies to
4. Configure your analytic accounts and percentages
5. Save the model
