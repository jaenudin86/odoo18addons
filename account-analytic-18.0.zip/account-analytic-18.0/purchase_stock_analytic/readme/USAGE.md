To use this module, you need to:

1.  Create a purchase order
2.  Set analytic distribution on purchase order lines
3.  Confirm purchase order
4.  ... and you should have your analytic distribution on your stock
    moves
