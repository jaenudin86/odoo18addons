This module restores the sequence for an analytic account.
