The module restores the possibility of defining analytical tags in sale
order lines so that the analytical items generated have those tags.
