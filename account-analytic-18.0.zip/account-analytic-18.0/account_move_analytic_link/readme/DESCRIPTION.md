This module allows users to navigate from posted journal items that have analytic distribution assigned to the analytic items generated.
