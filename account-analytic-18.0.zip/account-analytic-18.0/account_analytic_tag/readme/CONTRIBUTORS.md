- [Tecnativa](https://www.tecnativa.com):
  - Yadier Quesada
  - Víctor Martínez

- [APSL - Nagarro](https://apsl.tech/es/):
  - Miquel Pascual