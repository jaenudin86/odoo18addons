This module restores the *account analytic tags* as a method for
categorizing analytic entries, selectable from the invoices, and
transferred to them on publishing.
