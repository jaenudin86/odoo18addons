To manage analytic account tags using this module, you need to:

1.  Go to **Invocing \> Configuration \> Settings** and check the
    Analytic Tags checkboxs in the Analytics section.
