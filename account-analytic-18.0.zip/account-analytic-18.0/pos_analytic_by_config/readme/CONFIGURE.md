To configure the analytic distributions by store:

1.  Go to *Invoicing \> Configuration \> Analytic Distribution Models*
2.  We'll create one for every pos config.
3.  Select an account prefix (Normally your incoming account prefix)
4.  Select a PoS config (unhide it from the optionl fields).
5.  Choose your desired distribution for that store.
