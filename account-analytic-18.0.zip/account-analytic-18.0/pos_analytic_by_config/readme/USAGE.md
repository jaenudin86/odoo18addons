When you reconcile your sessions, the analytic distribution should go as
expected for your point of sale.
