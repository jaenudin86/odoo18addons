1.  Go to Invoicing \> Configuration \> Analytic Accounting \> Manual
    Analytic Distributions
2.  Create or edit the necessary records.
