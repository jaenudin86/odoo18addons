Compatibility with Analytic Distribution Models to use Manual
Distribution as Default values
