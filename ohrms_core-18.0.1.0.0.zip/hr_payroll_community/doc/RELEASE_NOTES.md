## Module <hr_payroll_community>

#### 01.10.2024
#### Version 18.0.1.0.0
#### ADD
- Initial commit for Odoo18 Payroll
