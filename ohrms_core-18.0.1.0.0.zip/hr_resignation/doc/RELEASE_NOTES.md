## Module <hr_resignation>
#### 03.10.2024
#### Version 18.0.1.0.0
##### ADD   
- Initial commit for Open HRMS Resignation
