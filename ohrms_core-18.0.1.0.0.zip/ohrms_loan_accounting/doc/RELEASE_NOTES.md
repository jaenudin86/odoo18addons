## Module <ohrms_loan_accounting>
#### 28.11.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Open HRMS Loan Accounting
