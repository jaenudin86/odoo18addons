## Module <oh_employee_creation_from_user>
#### 01.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Open HRMS Employees From User
