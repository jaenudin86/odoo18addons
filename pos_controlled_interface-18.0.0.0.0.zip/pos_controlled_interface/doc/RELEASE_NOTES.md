## Module <pos_controlled_interface>

#### 05.12.2024
#### Version 18.0.1.0.0
#### ADD
- Initial Commit for Controlled Point Of Sale
