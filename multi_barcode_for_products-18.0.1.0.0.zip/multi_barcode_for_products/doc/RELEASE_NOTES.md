## Module <multi_barcode_for_products>

#### 16.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Multi Barcode for Products
